<h2>MSX</h2>

Code example

```
<div style="width:640px;height:480px;max-width:100%">
        <div id="game"></div>
      </div>
<script type="text/javascript">
    EJS_player = '#game';
    EJS_biosUrl = ''; // Url to Bios file
    EJS_gameUrl = ''; // Url to Game rom
    EJS_core = 'msx';
    EJS_pathtodata = 'data/'; //path to all of the wasm and js files. MUST all be in the same directory!!
</script>
<script src="data/loader.js"></script>
```

I do not know the file extension limits for this system.

<p>You can download the 'Databases' and 'Machines' folders from an <a href='http://bluemsx.msxblue.com/download.html'>official full standalone blueMSX emulator installation.</a> Get blueMSXv282full.zip near the bottom of the page.</p>
Compress the 'Databases' and 'Machines' Folders to 7z or zip archive.
